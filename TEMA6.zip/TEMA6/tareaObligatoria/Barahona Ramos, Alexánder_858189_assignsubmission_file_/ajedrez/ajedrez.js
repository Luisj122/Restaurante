window.onload = function iniciar() {
    crearTablero();
    document.getElementById("limpiar").addEventListener("click", limpiar, false);
    document.getElementById("rojo").addEventListener("click", rojo, false);
    document.getElementById("borrar").addEventListener("click", borrar, false);
    document.getElementById("ajedrez").addEventListener("click", ajedrez, false);
    document.getElementById("sumarRojos").addEventListener("click", sumarRojos, false);
    document.getElementById("sumarBlancos").addEventListener("click", sumarBlancos, false);
}

//crea el tablero con sus numero no repetidos
function crearTablero() {
    const arrayN = [];
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            num = noRepetidos(arrayN);
            let div = document.createElement('div');
            let text1 = document.createTextNode(num);
            div.setAttribute('id', i+j);
            div.setAttribute('class', "blanco");
            arrayN.push(num);

            div.addEventListener("click", pintarDiv, false);

            div.appendChild(text1);
            document.body.appendChild(div);
        }
        let br = document.createElement('br');
        document.body.appendChild(br);
    }
}

//busca el numero no repetic y lo retorna
function noRepetidos(arrayN) {
    for (let i = 0; i < 15; i++) {
        do {
            numero = Math.round(Math.random() * 15);
        } while (arrayN.includes(numero));

        return numero;
    }
}

//limpia  el tablero para pintarlo todo de blanco
function limpiar() {

    let divs = document.getElementsByTagName("div");
    for (let i = 0; i < divs.length; ++i) {

        divs[i].style.background = "white";
        divs[i].className = "blanco";
    }

}

let colorActual = "";

//pinta de rojo el div
function rojo() {
    colorActual = "red";
}

//pinta de blanco el div q es borrar
function borrar() {
    colorActual = "white";
}

//pinta el ajedrez
function ajedrez() {
    let divs = document.getElementsByTagName("div");
    for (let i = 0; i < divs.length; i++) {
        if (divs[i].getAttribute("id")%2==0) { 
            divs[i].className = "rojo"
            divs[i].style.background = "red";

        }else{
            divs[i].className = "blanco"
            divs[i].style.background = "white";
        }
    }
}

//suma todos los div pintado con rojo
function sumarRojos() {
    let cantidad = 0;
    let divs = document.getElementsByTagName("div");
    for (let i = 0; i < divs.length; ++i) {
        if (divs[i].className == "rojo") {
            cantidad += parseInt(divs[i].textContent);
        }
    }

    document.getElementById("mensaje").innerHTML = "La suma de rojos es de " + cantidad;
}

//suma todos los div pintado con blanco
function sumarBlancos() {
    let cantidad = 0;
    let divs = document.getElementsByTagName("div");
    for (let i = 0; i < divs.length; ++i) {
        if (divs[i].className == "blanco") {
            cantidad += parseInt(divs[i].textContent);
        }
    }

    document.getElementById("mensaje").innerHTML = "La suma de blancos es de " + cantidad;
}

//pinta el div determinado
function pintarDiv() {
    this.style.background = colorActual;
    if (colorActual == "red") {
        this.setAttribute("class", "rojo")
    } else if (colorActual == "white") {
        this.setAttribute("class", "blanco")
    }


}



