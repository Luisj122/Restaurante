window.addEventListener("load", inicio, false);

/**
 * Llama la funcion de crear el tablero y asocia los eventos a los botones
 */
function inicio() {
    crearTablero();
    document.getElementById("limpiar").addEventListener("click", limpiar, false);
    document.getElementById("rojo").addEventListener("click", pintarRojo, false);
    document.getElementById("blanco").addEventListener("click", pintarBlanco, false);
    document.getElementById("ajedrez").addEventListener("click", ajedrez, false);
    document.getElementById("sumaR").addEventListener("click", sumarRojas, false);
    document.getElementById("sumaB").addEventListener("click", sumarBlancas, false);
}

/**
 * Crea el tablero
 */
function crearTablero() {
    let tablero = document.getElementById('tablero');
    let secuencia = [];
    let numero = 0;
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {

            // Creamos la casilla y asignamos el id y la clase
            let casilla = document.createElement('div');
            // Generamos numeros aleatorio no repetido
            numero = comprobarRepetidos(secuencia);
            // Introducimos dicho numero en el array secuencia
            secuencia.push(numero);
            // Asociamos el numero al id
            casilla.setAttribute("id", numero);
            casilla.className = "casilla blanca";
            casilla.appendChild(document.createTextNode(numero));
            tablero.appendChild(casilla);
            
            // Cuando se haga click la casilla pasa a rojo
            casilla.addEventListener("click", seleccionar, false);
        }
    }
}

/**
 * Comprueba que los numeros aleatorios no esten repetidos
 */
function comprobarRepetidos(secuencia) {
    for (let i = 0; i < 16; i++) {
        let numero = 0;
        do {
            numero = Math.round(Math.random() * 15);
        } while (secuencia.includes(numero));
        return numero;
    }
}

/**
 * Por defecto, cambia el color a rojo al empezar
 */
function seleccionar(e) {
    e.target.className = "casilla roja";
}

/**
 * Limpiar el tablero y cambia todas las casilla a color blanco
 */
function limpiar() {
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if (tablero.getElementsByTagName("div")[i].className == "casilla roja") {
            tablero.getElementsByTagName("div")[i].className = "casilla blanca";
        }
    }
}

/**
 * Cambia a color blanco las casillas rojas que se pulsen
 */
function pintarBlanco() {
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if (tablero.getElementsByTagName("div")[i].className == "casilla roja") {
            tablero.getElementsByTagName("div")[i].addEventListener("click", function pinBlanco() {
                this.className = "casilla blanca";
            }, false);
        }
    }
}

/**
 * Cambia a color rojo las casillas blancas que se pulsen
 */
function pintarRojo() {
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if (tablero.getElementsByTagName("div")[i].className == "casilla blanca") {
            tablero.getElementsByTagName("div")[i].addEventListener("click", function pinRojo() {
                this.className = "casilla roja";
            }, false);
        }
    }
}

/**
 * Pinta todas las casillas como si fuera un tablero de ajedrez
 */
function ajedrez() {
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if ((i < 4) || (i > 7 && i < 12)) {
            if (i % 2 == 0) 
                tablero.getElementsByTagName("div")[i].className = "casilla blanca";
            else 
                tablero.getElementsByTagName("div")[i].className = "casilla roja";
        } else if ((i > 3 && i < 8) || (i > 11)) {
            if (i % 2 == 0) 
                tablero.getElementsByTagName("div")[i].className = "casilla roja";
            else 
                tablero.getElementsByTagName("div")[i].className = "casilla blanca";
        }
    }
}

/**
 * Suma el valor de las casillas de color rojo
 */
function sumarRojas() {
    let suma = 0;
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if (tablero.getElementsByTagName("div")[i].className == "casilla roja") {
            suma += parseInt(tablero.getElementsByTagName("div")[i].id);
        }
    }
    document.getElementById("resultado").innerHTML = "Las rojas son: " + suma;
}

/**
 * Suma el valor de las casillas de color blanco
 */
function sumarBlancas() {
    let suma = 0;
    let tablero = document.getElementById('tablero');
    for (let i = 0; i < tablero.getElementsByTagName("div").length; i++) {
        if (tablero.getElementsByTagName("div")[i].className == "casilla blanca") {
            suma += parseInt(tablero.getElementsByTagName("div")[i].id);
        }
    }
    document.getElementById("resultado").innerHTML = "Las blancas son: " + suma;
}