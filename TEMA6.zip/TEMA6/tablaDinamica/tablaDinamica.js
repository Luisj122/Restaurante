window.onload=function inicio(){
    document.getElementById("añadir").addEventListener("click",añadirFila,false);
    document.getElementById("borrar").addEventListener("click",borrarFila,false);
}

function llenarLista(){
    let lista=document.getElementById("lista");
    let li=document.createElement("li");
    let contenido=document.createTextNode(prompt("Introduce una poblacion que quieras añadir"));
    li.appendChild(contenido);
    lista.appendChild(li);

}

function añadirFila() {

    let table = document.getElementById("table");
    let tr = document.createElement("tr");

    let td1 = document.createElement("td");
    let td2 = document.createElement("td");
    let td3 = document.createElement("td");
    let td4 = document.createElement("td");

    let c1 = document.getElementById("celda1").value;
    let c2 = document.getElementById("celda2").value;
    let c3 = document.getElementById("celda3").value;

    td1.appendChild(c1);
    td2.appendChild(c2);
    td3.appendChild(c3);

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(tr3);

    table.appendChild(tr);

    
}